<?php
// Include the database connection file
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    
    $bloodBankName = $_POST["bloodBankName"];
    $location = $_POST["location"];
    $city = $_POST["City"];
    $state = $_POST["State"];
    $email = $_POST["Email"];
    $password = $_POST["Password"];
    
    // Availability of Blood
    $available_pos_A = $_POST["available_pos_A"];
    $available_pos_B = $_POST["available_pos_B"];
    $available_neg_A = $_POST["available_neg_A"];
    $available_neg_B = $_POST["available_neg_B"];
    $available_pos_AB = $_POST["available_pos_AB"];
    $available_neg_AB = $_POST["available_neg_AB"];
    $available_pos_O = $_POST["available_pos_O"];
    $available_neg_O = $_POST["available_neg_O"];

    $BBID = $_POST["BBID"];
    $taluka = $_POST["taluka"];
    $mobile = $_POST["mobile"];

    // Insert data into the database
    $sql = "INSERT INTO blood_bank_reg (bloodBankName, location, city,state, email, password, available_pos_A, available_pos_B, available_neg_A, available_neg_B, available_pos_AB, available_neg_AB, available_pos_O, available_neg_O, BBID,taluka,mobile) 
            VALUES ('$bloodBankName', '$location', '$city', '$state', '$email', '$password', '$available_pos_A', '$available_pos_B', '$available_neg_A', '$available_neg_B',' $available_pos_AB', '$available_neg_AB', '$available_pos_O', '$available_neg_O','$BBID','$taluka','$mobile')";


    



    if ($db->query($sql) === TRUE) {
        echo "Blood Bank registered successfully";
        header('location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . $db->error;
    }
}

// Close the database connection
$db->close();
?>
