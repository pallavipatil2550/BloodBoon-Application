<?php

session_start();

if (isset($_SESSION['email'])) {
    header("location: index.php");
    exit;
}

// Include the database connection file
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Initialize variables
$email = $password = "";
$err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty(trim($_POST['email'])) || empty(trim($_POST['password']))) {
        $err = "Please enter email and password.";
    } else {
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
    }

    if (empty($err)) {
        $sql = "SELECT email, password FROM donor_reg WHERE email = ?";
        $stmt = mysqli_prepare($db, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = $email;

            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result($stmt, $email, $hashed_password);

                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            $_SESSION["email"] = $email;
                            $_SESSION["loggedin"] = true;

                            header("location: index.php");
                            exit;
                        } else {
                            $err = "Invalid password.";
                        }
                    }
                } else {
                    $err = "Invalid email.";
                }
            } else {
                $err = "Something went wrong. Please try again later.";
            }

            mysqli_stmt_close($stmt);
        } else {
            $err = "Statement preparation failed.";
        }
    }
}

// Rest of your HTML or PHP code goes here

?>
