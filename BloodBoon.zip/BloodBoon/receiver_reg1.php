<?php
    include("receiver_reg2.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Request Form</title>
    <link rel="stylesheet" href="receiver_reg1.css">
</head>
<body>
    <div class="container">

    <h2>Blood Receiver Registration</h2>

    <form action="receiver_reg1.php" method="post">

        <label for="receiverName">Receiver Name:</label>
        <input type="text" name="receiverName" required><br>

        <label for="age">Age:</label>
        <input type="number" name="age" required><br>
        
        <label>Gender:</label>
        <select name="gender" required>
                <option value="select gender">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
        </select>

        <label for="address">Address:</label>
        <input type="text" name="address" required><br>

        <label for="taluka">Taluka:</label> 
        <input type = "text" name="taluka" id="taluka">


        <label for="city">City / District:</label>
        <input type="text" name="city" required><br>

        <label for="mobile">Contact Number:</label>
        <input type="number" name="mobile" required><br>

        <label for="Email">Email:</label>
        <input type="email" name="Email" required><br>

        <label for="bloodGroup">Blood Group:</label>
        <input type="text" name="bloodGroup" required><br>

        <label for="amountNeeded">Amount of Blood Needed:</label>
        <input type="number" name="amountNeeded" required><br>

        <label for="dateNeeded">Date Up To Blood Needed:</label>
        <input type="date" name="dateNeeded" required><br>

        <label for="Password">create new password:</label> 
            <!-- <p>Password : <input type="password" required></p> -->
        <input type="password" name="Password" required><br>
        <br>

        

        <input  class= "button" type="submit" name= "sub" value="Submit">

    </form>
    </div>

</body>
</html>
