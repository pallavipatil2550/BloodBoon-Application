<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>BLOOD BOON APPLICATION</title>
    <link rel="stylesheet" href="style6.css" />
    <!-- Fontawesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" />
  </head>
  <body>
    <nav class="sidebar">
      
      <p class="logo">BLOOD BOON </p>


      <div class="menu-content">
        <ul class="menu-items">
          <li class="item">
            <a href="index.php">Home</a>
          </li>

          


          <li class="item">
            <div class="submenu-item">
              <span>Blood Bank</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                Your submenu title
              </div>
              <li class="item">
                <a href="bloodbank_reg1.php"> new registration</a>
              </li>
              <li class="item">
                <a href="blood_bank_login.php"> login/sign up</a>
              </li>
              <li class="item">
                <a href="logout/bloodbank_logout.php"> log out</a>
              </li>
              
            </ul>
          </li>



          <li class="item">
            <div class="submenu-item">
              <span>Donor</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                Your submenu title
              </div>
              <li class="item">
                <a href="donor1.php"> new registration</a>
              </li>
              <li class="item">
                <a href="donor_login.php"> login/sign up</a>
              </li>
              <li class="item">
                <a href="logout/donor_logout.php"> log out</a>
              </li>
            </ul>
          </li>
          <li class="item">
            <div class="submenu-item">
              <span>Reciever</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                Your submenu title
              </div>
              <li class="item">
                <a href="receiver_reg1.php">new registration</a>
              </li>
              <li class="item">
                <a href="receiver_login.php">login/sign up</a>
              </li>
              <li class="item">
                <a href="logout/receiver_logout.php">log out</a>
              </li>
              
            </ul>
          </li>

          <li class="item">
            <a href="aboutus.php">About us</a>
          </li>

          <li class="item">
            <a href="contactus.php">Contact us</a>
          </li>
          
        </ul>
      </div>
    </nav>

    <nav class="navbar">
    <h1 style="text-align: center;">BLOOD BOON</h1> 
      <i class="fa-solid fa-bars" id="sidebar-close"></i>
    </nav>

    <main class="main">
       <div id="margin">
       </div>
    </main>

    <script src="script6.js"></script>
  </body>
</html>
