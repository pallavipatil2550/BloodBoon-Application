<?php
// Connect to the database
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Get the current date
$currentDate = date('Y-m-d');

// Query to select registrations with dateNeeded less than the current date
$selectQuery = "SELECT * FROM receiver_reg WHERE dateNeeded < '$currentDate'";
$result = $db->query($selectQuery);

if (!$result) {
    die("Query failed: " . $db->error);
}

// Loop through the results and delete the registrations
while ($row = $result->fetch_assoc()) {
    $receiverName = $row['receiverName'];

    // Check if 'Email' key exists in the array before accessing it
    if (isset($row['Email'])) {
        $email = $row['Email'];

        $deleteQuery = "DELETE FROM receiver_reg WHERE receiverName='$receiverName' AND Email='$email'";
        $deleteResult = $db->query($deleteQuery);

        if (!$deleteResult) {
            die("Deletion failed: " . $db->error);
        }

        echo "Registration removed for $receiverName (Email: $email) due to expired dateNeeded.\n";
    } else {
        echo "Skipping deletion for $receiverName due to missing Email.\n";
    }
}

// Close the database connection
$db->close();
?>
