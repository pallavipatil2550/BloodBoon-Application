<?php
session_start();
$receiverName = "";
$age = "";
$gender = "";
$address = "";
$city = "";
$mobile = "";
$Email = "";
$bloodGroup = "";
$amountNeeded = "";
$dateNeeded = "";
$Password = "";
$taluka = "";




$errors = array();

// Create connection
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if (isset($_POST['sub'])) {
    // receive all input values from the form
    $receiverName = mysqli_real_escape_string($db, $_POST['receiverName']);
    $age = mysqli_real_escape_string($db, $_POST['age']);
    $gender = mysqli_real_escape_string($db, $_POST['gender']);
    $address = mysqli_real_escape_string($db, $_POST['address']);
    $city = mysqli_real_escape_string($db, $_POST['city']);
    $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
    $Email = mysqli_real_escape_string($db, $_POST['Email']);
    $bloodGroup = mysqli_real_escape_string($db, $_POST['bloodGroup']);
    $amountNeeded = mysqli_real_escape_string($db, $_POST['amountNeeded']);
    $dateNeeded = mysqli_real_escape_string($db, $_POST['dateNeeded']);
    $Password = mysqli_real_escape_string($db, $_POST['Password']);
    $taluka = mysqli_real_escape_string($db, $_POST['taluka']);
    
    
    


    // form validation
    if (empty($receiverName)) {
        array_push($errors, "Receiver name is required");
    }
    if (empty($age)) {
        array_push($errors, "Age is required");
    }
    if (empty($gender)) {
        array_push($errors, "Gender is required");
    }
    if (empty($address)) {
        array_push($errors, "Address is required");
    }
    
    if (empty($city)) {
        array_push($errors, "City is required");
    }
    if (empty($mobile)) {
        array_push($errors, "Mobile no. is required");
    }

    if (empty($Email)) {
        array_push($errors, "Email is required");
    }
    if (empty($bloodGroup)) {
        array_push($errors, "blood group is required");
    }
    if (empty($amountNeeded)) {
        array_push($errors, "Amount of blood  is required");
    }

    if (empty($dateNeeded)) {
        array_push($errors, "Blood needed date is required");
    }

    if (empty($Password)) {
        array_push($errors, "Password is required");
    }

    if (empty($taluka)) {
        array_push($errors, "taluka is required");
    }

    


    
    // Check if user already exists
    $user_check_query = "SELECT * FROM receiver_reg WHERE receiverName='$receiverName' OR Email='$Email' LIMIT 1";
    $result = $db->query($user_check_query);

    if (!$result) {
        die("Query failed: " . $db->error);
    }

    $user = $result->fetch_assoc();

    if ($user) {
        if ($user['receiverName'] === $receiverName) {
            array_push($errors, "Donor name already exists");
        }

        if ($user['Email'] === $Email) {
            array_push($errors, "Email already exists");
        }
    }

    // Register user if there are no errors
    if (count($errors) == 0) {
        $hashed_password = password_hash($Password, PASSWORD_DEFAULT);

        $query = "INSERT INTO receiver_reg (receiverName, age,gender,address, city,mobile, Email,  bloodGroup, amountNeeded, dateNeeded,  Password , taluka) 
                  VALUES ('$receiverName','$age', '$gender','$address', '$city', '$mobile', '$Email',    '$bloodGroup', '$amountNeeded', '$dateNeeded', '$Password' , '$taluka' )";

        $result = $db->query($query);

        if ($result) {
            $_SESSION['receiverName'] = $receiverName;
            $_SESSION['success'] = "You are now logged in";
            header('location: index.php');
            exit();
        } else {
            die("Registration failed: " . $db->error);
        }
    }
}





$db->close();
?>
