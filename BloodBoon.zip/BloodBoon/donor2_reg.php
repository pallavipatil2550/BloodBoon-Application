




<?php
// Include the database connection file
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $donorName =  $_POST['donorName'];
    $donorAddress =  $_POST['donorAddress'];
    $state =  $_POST['state'];
    $city =  $_POST['city'];
    $Email =  $_POST['Email'];
    $mobile =  $_POST['mobile'];
    $gender = $_POST['gender'];
    $age =  $_POST['age'];
    $weight =  $_POST['weight'];
    $dob =  $_POST['dob'];
    $hb =  $_POST['hb'];
    $diseases =  $_POST['diseases'];
    $Password =  $_POST['Password'];
    $taluka = $_POST['taluka'];
   
    

    // Insert data into the database
    $sql = "INSERT INTO donor_reg (donorName, donorAddress, state, city, Email, mobile, gender, age, weight, dob, hb, diseases, Password,taluka) VALUES ('$donorName', '$donorAddress', '$state', '$city', '$Email', '$mobile', '$gender', '$age', '$weight', '$dob', '$hb', '$diseases', '$Password','$taluka')";
    
    if ($db->query($sql) === TRUE) {
        echo "Blood Bank registered successfully";
        header('location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . $db->error;
    }
}

// Close the database connection
$db->close();
?>
