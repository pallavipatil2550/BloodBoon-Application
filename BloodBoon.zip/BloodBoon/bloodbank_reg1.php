<?php
include('blood_bank_reg3.php');
?>

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank Registration Form</title>
    <link rel="stylesheet" href="bloodbank_reg.css">
</head>
<body>
    
    <div class="container">
    <h2>Blood Bank Information Form</h2>
    <form action="bloodbank_reg1.php" method="post">

        <label for="BBID">Blood Bank ID:</label>
        <input type="text"  name="BBID" required>

        <label for="bloodBankName">Blood Bank Name:</label>
        <input type="text"  name="bloodBankName" required>

        <label for="mobile">Mobile number:</label>
        <input type="number"  name="mobile" required>

        <label for="location">Location:</label>
        <input type="text"  name="location" required>

         <label for="taluka">Taluka:</label>
        <input type="text"  name="taluka" placeholder="1st letter must be capital" required>

        <label for="City">City / District:</label>
        <input type="text"  name="City" placeholder="1st letter must be capital" required>

        <label for="State">State:</label>
        <input type="text"  name="State" required>

        <label for="Email">Email:</label>
        <input type="Email"  name="Email" required>

        <label for="Password">Password:</label>
        <input type="Password"  name="Password" required>

        <label>Availability of Blood(IN LITRE):</label>
        <div>
            <label for="bloodGroupA+">A+:</label>
            <input type="number"  name="available_pos_A" min="0" required>
        </div>

        <div>
            <label for="bloodGroupB+">B+:</label>
            <input type="number"  name="available_pos_B" min="0" required>
        </div>

        <div>
            <label for="bloodGroupA-">A-:</label>
            <input type="number"  name="available_neg_A" min="0" required>
        </div>

        <div>
            <label for="bloodGroupB-">B-:</label>
            <input type="number"  name="available_neg_B" min="0" required>
        </div>

        <div>
            <label for="bloodGroupAB+">AB+:</label>
            <input type="number"  name="available_pos_AB" min="0" required>
        </div>

        <div>
            <label for="bloodGroupAB-">AB-:</label>
            <input type="number"  name="available_neg_AB" min="0" required>
        </div>


        <div>
            <label for="bloodGroupO+">O:</label>
            <input type="number"  name="available_pos_O" min="0" required>
        </div>

        <div>
            <label for="bloodGroupO-">O-:</label>
            <input type="number"  name="available_neg_O" min="0" required>
        </div>
        

       
        <input  class ="button" type="submit" name="sub" value="Register">
        
    </form>
    
    </div>
</body>
</html> 

