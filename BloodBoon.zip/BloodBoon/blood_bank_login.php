<?php
// Include  database connection
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// If the submit button is clicked
if (isset($_REQUEST['submit'])) {
    // Check if the Email and Password fields are not empty
    if ($_REQUEST['Email'] == "" || $_REQUEST['Password'] == "") {
        echo "Fields must be filled";
    } else {
        // Use prepared statement to prevent SQL injection
        $sql = "SELECT * FROM blood_bank_reg WHERE Email = ? AND Password = ?";
        $stmt = $db->prepare($sql);

        // Bind parameters
        $stmt->bind_param("ss", $_REQUEST['Email'], $_REQUEST['Password']);

        // Execute the query
        if ($stmt->execute()) {
            // Store the result
            $result = $stmt->get_result();

            // Check the number of rows
            $num_rows = $result->num_rows;

            if ($num_rows > 0) {
                // Redirect or display success message
                 header("location:fetch data/blood_bank_data.php");
                //echo "You have logged in successfully";
            } else {
                echo "Username or password incorrect";
            }
        } else {
            echo "Error executing the query: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
}

// Close the database connection
$db->close();
?>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            transition: box-shadow 0.3s ease-in-out;
        }

        .login-container:focus-within {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on focus */
        }

        .login-heading {
            background-color: #ff0000; /* Red background for the "Login" heading */
            color: #fff; /* White color for the "Login" heading text */
            text-align: center;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .login-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s ease-in-out;
        }

        .form-group input:focus {
            border-color: #ff0000; /* Red border on focus */
        }

        .submit-btn {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease-in-out, color 0.3s ease-in-out;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        .submit-btn:focus {
            outline: none;
            background-color: #ff0000; /* Red background on focus */
            color: #fff; /* White color on focus */
        }
    </style>
    


</head>
<body>
    


        <div class="login-container" tabindex="0">
    <div class="login-heading">Login</div>
    <form class="login-form" action="blood_bank_login.php" method="post">
        <div class="form-group">
            <label for="Email">Email:</label>
            <input type="email" name="Email" required>
        </div>
        <div class="form-group">
            <label for="Password">Password:</label>
            <input type="password" name="Password" required>

        </div>
        <button type="submit"  name="submit" class="submit-btn">Submit</button>
    </form>
</div>




   

    
</body>
</html>
