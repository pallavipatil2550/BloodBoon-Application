<?php

//include('blood_bank_fetch_data.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the selected city and taluka
    $selectedCity = $_POST['city'];
    $selectedTaluka = $_POST['taluka'];

    // Perform any additional processing if needed

    // Redirect to the display locations page
    header("Location: fetch data/data.php?city=" . urlencode($selectedCity));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Larger Data Entry Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            transition: box-shadow 0.3s ease-in-out;
        }

        .form-container:hover {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on hover */
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 15px;
        }

        .form-group label {
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input,
        .form-group select {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .blood-group-label {
            background-color: #ff0000; /* Red background for the label */
            color: #fff; /* White text color */
            text-align: center;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .blood-group-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 15px;
        }

        .blood-group {
            background-color: #007bff; /* Blue background for blood group boxes */
            color: #fff; /* White text color */
            padding: 15px;
            border-radius: 4px;
            text-align: center;
            cursor: pointer;
            flex: 1 1 calc(25% - 10px); /* Equal size for four blood group boxes in a row */
            transition: background-color 0.3s ease-in-out;
        }

        .blood-group:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        .submit-btn {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease-in-out, color 0.3s ease-in-out;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        .submit-btn:focus {
            outline: none;
            background-color: #ff0000; /* Red background on focus */
            color: #fff; /* White color on focus */
        }

        .taluka-options {
            display: none;
        }
    </style>
</head>

<body>

    <form method="post" action="fetch data/data.php" onsubmit="return validateForm();">
        <div class="form-container" tabindex="0">
            <div class="form-group">
                <label for="selectedBlood">Selected Blood:</label>
                <input type="text" id="selectedBlood" name="selectedBlood" readonly>
            </div>

            <div class="blood-group-label">Blood Groups</div>
            <div class="blood-group-container">
                <div class="blood-group" onclick="handleBloodGroup('A+');">A+</div>
                <div class="blood-group" onclick="handleBloodGroup('A-');">A-</div>
                <div class="blood-group" onclick="handleBloodGroup('B+');">B+</div>
                <div class="blood-group" onclick="handleBloodGroup('B-');">B-</div>
                <div class="blood-group" onclick="handleBloodGroup('O+');">O+</div>
                <div class="blood-group" onclick="handleBloodGroup('O-');">O-</div>
                <div class="blood-group" onclick="handleBloodGroup('AB+');">AB+</div>
                <div class="blood-group" onclick="handleBloodGroup('AB-');">AB-</div>
            </div>

            <div class="form-group">
                <label for="city">City:</label>
                <select id="city" name="city" onchange="handleCityChange(this.value)">
                    <option value="">Select city</option>
                    <option value="Sangli">Sangli</option>
                    <option value="Kolhapur">Kolhapur</option>
                    <option value="Pune">Pune</option>
                    <option value="Satara">Satara</option>
                    <option value="Nashik">Nashik</option>
                    <option value="Latur">Latur</option>
                    <option value="Solapur">Solapur</option>
                    <option value="Mumbai">Mumbai</option>
                    <option value="Ratnagiri">Ratnagiri</option>
                </select>
            </div>

            <div class="form-group">
                <label for="taluka">Taluka:</label>
                <select id="taluka" name="taluka" class="taluka-options dynamic-options">
                    <option value="">Select Taluka</option>
                </select>
            </div>

            <input type="submit" name="submit" class="submit-btn">
        </div>
    </form>

    <script>
        var talukaOptions = {
            'Sangli': ['Miraj', 'Walwa', 'Jat', 'Tasgaon', 'Khanapur/Vita', 'Palus', 'Shirala', 'Kavathemahankal', 'Kadegaon', 'Atpadi'],
            'Pune': ['Junnar', 'Ambegaon', 'Khed', 'Maval', 'Pune City', 'Mulashi', 'Velhe', 'Bhor', 'Haveli', 'Baramati', 'Shirur', 'Indapur'],
            'Kolhapur': ['Karvir', 'Panhala', 'Shahuwadi', 'Kagal', 'Hatkangale', 'Shirol', 'Radhanagari', 'Gaganbawada', 'Gadhinglaj', 'Chandgad', 'Ajra', 'Bhudargad'],
            'Satara': ['Satara', 'Karad', 'Wai', 'Phalatan', 'Man', 'Khatav', 'Koregaon', 'Patan', 'Jaoli', 'Khandala'],
            'Nashik': ['Nashik', 'Malegaon', 'Baglan', 'Sinnar', 'Dindori', 'Niphad', 'Nandegaon', 'Yevla', 'Ingatpuri', 'Chandvad', 'Kalwan', 'Surgana', 'Trimbekeshwar', 'Deola', 'Peint'],
            'Latur': ['Latur', 'Udgir', 'Ahmedpur', 'Ausa', 'Nilanga', 'Renapur', 'Chakur', 'Deoni', 'Shirur', 'Anantpal', 'Jalkot'],
            'Solapur':['North Solapur', 'South Solapur', 'Akkalkot', 'Barshi', 'Mangalwedha',' Pandharpur', 'Sangola',' Malshiras', 'Mohol', 'Madha' ,'Karmala'],
            'Mumbai':['Andheri', 'Borivali ','Kurla' ],
            'Ratnagiri':['Rajapur', 'Lanja', 'Sangmeshwar', 'Chiplun','Guhagar', 'Khed',' Dapoli ',' Mandangad'],
            
        };
        function handleBloodGroup(bloodGroup) {
            document.getElementById('selectedBlood').value = bloodGroup;
            console.log('Selected Blood Group:', bloodGroup);
            // Your logic to send data to the server or update the UI goes here
        }

        function handleCityChange(selectedCity) {
            var talukaDropdown = document.getElementById('taluka');
            var talukaOptionsArray = talukaOptions[selectedCity] || [];

            // Clear existing options
            talukaDropdown.innerHTML = '<option value="">Select Taluka</option>';

            // Add new taluka options
            talukaOptionsArray.forEach(function (taluka) {
                var option = document.createElement('option');
                option.value = taluka;
                option.text = taluka;
                talukaDropdown.add(option);
            });

            // Show/hide taluka dropdown based on the selected city
            talukaDropdown.classList.toggle('taluka-options', talukaOptionsArray.length === 0);
        }

        function validateForm() {
            var selectedBlood = document.getElementById('selectedBlood').value;
            var selectedCity = document.getElementById('city').value;
            var selectedTaluka = document.getElementById('taluka').value;

            // Check if a blood group is selected
            if (!selectedBlood) {
                alert('Please select a blood group.');
                return false; // Prevent form submission
            }

            // Check if a city is selected
            if (!selectedCity) {
                alert('Please select a city.');
                return false; // Prevent form submission
            }

            // Check if a taluka is selected
            if (!selectedTaluka) {
                alert('Please select a taluka.');
                return false; // Prevent form submission
            }

            // You can add additional validation logic here if needed

            return true; // Allow form submission
        }
    </script>

</body>

</html>
