<?php
    include('donor2_reg.php')
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="donor1.css">
    <title>Blood Donor Registration</title>

    



</head>
<body>
    <div class="container">
        <h2>Blood Donor Registration Form</h2>
        <form action="donor1.php" method="post" onsubmit="getLatLong()">
            <label for="donorName">Donor Name:</label>
            <input type="text" name="donorName" required>

            <label for="donorAddress">Donor Address:</label>
            <input type="text" name="donorAddress" required>

            <label for="taluka">Taluka:</label>
            <input type="text"  name="taluka" required>


            <label for="city">City / District:</label>
            <input type="text" name="city" required>

            <label for="state">State:</label>
            <input type="text" name="state" required>

            

            <label for="Email">Email:</label>
            <input type="email" name="Email" required>

            <label for="mobile">Mobile Number:</label>
            <input type="number" name="mobile" required>

            <label for="gender">Gender:</label>
            <select name="gender" required>
                <option value="select gender">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label for="age">age (greater than 18):</label>
            <input type="age" name="age" min="18" required>

            <label for="weight">Weight (in kg, greater than 50):</label>
            <input type="number" name="weight" min="51" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" name="dob" required>

            <label for="hb">Hemoglobin (Hb) Level:</label>
            <input type="text" name="hb" required>

            <label for="diseases">Any Diseases? If yes, please specify:</label>
            <textarea name="diseases"></textarea>

            <label for="Password">create new password:</label> 
            <!-- <p>Password : <input type="password" required></p> -->
            <input type="password" name="Password" required>

            

            
            
            <input class="button" type="submit" name="submit" value="Register">
            <!-- <button type="submit">Submit</button> -->
        </form>
    </div>
</body>
</html>
