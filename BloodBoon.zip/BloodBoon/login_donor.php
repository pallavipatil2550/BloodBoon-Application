<?php
    include('login_donor2.php')
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            transition: box-shadow 0.3s ease-in-out;
        }

        .login-container:focus-within {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on focus */
        }

        .login-heading {
            background-color: #ff0000; /* Red background for the "Login" heading */
            color: #fff; /* White color for the "Login" heading text */
            text-align: center;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .login-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s ease-in-out;
        }

        .form-group input:focus {
            border-color: #ff0000; /* Red border on focus */
        }

        .submit-btn {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease-in-out, color 0.3s ease-in-out;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        .submit-btn:focus {
            outline: none;
            background-color: #ff0000; /* Red background on focus */
            color: #fff; /* White color on focus */
        }
    </style>
</head>
<body>
    

<div class="login-container" tabindex="0">
    <div class="login-heading">Login</div>
    <form class="login-form" action="login_donor.php" method="post">
        <div class="form-group">
            <label for="email">Username (Email):</label>
            <input type="email"  name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password"  name="password" required>
        </div>
        <input type="submit" name="login" class="submit-btn" value="submit">
        
    </form>
</div>

</body>
</html>
