<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Google Maps API in PHP</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <script type="text/javascript" src="googlemap.js"></script>
    <style type="text/css">
        .container {
            height: 450px;
        }
        #map {
            width: 100%;
            height: 100%;
            border: 1px solid blue;
        }
    </style>
</head>
<body>
    <div class="container">
        <center><h1>Access Google Maps API in PHP</h1></center>
        <div id="map"></div>
    </div>

    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBWzfpRqt1HLhycqyJROw671dqdcuqKuU8&callback=loadmap"></script>
</body>
</html>

