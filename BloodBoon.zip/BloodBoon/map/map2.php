<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Simple Google Maps Example</title>
  <style>
    #map {
      height: 400px;
    }
  </style>
</head>
<body>
  <div id="map"></div>

  <script>
    function initMap() {
      var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 8, // Set an initial zoom level
        center: { lat: 0, lng: 0 } // Default center if no locations are available
      });

      // Fetch data from PHP script
      fetch('map3.php')
        .then(response => response.json())
        .then(data => {
          data.locations.forEach(location => {
            var latLng = new google.maps.LatLng(parseFloat(location.lat), parseFloat(location.lng));

            var marker = new google.maps.Marker({
              position: latLng,
              map: map,
              title: location.name,
            });
          });

          // Set the center of the map based on the calculated center
          if (data.center) {
            map.setCenter(new google.maps.LatLng(parseFloat(data.center.lat), parseFloat(data.center.lng)));
          }
        });
    }
  </script>

  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDEVtxWO0K-Bb8cuohNfUjGpNPcdufDmPEcallback=initMap">
</script>
</body>
</html>
