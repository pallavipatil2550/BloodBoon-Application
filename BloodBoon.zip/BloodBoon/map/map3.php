<?php
  $conn = new mysqli("localhost", "root", "", "bloodboon");

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $result = $conn->query("SELECT * FROM blood_bank_reg");

  $locations = array();
  while ($row = $result->fetch_assoc()) {
    $locations[] = array('lat' => $row['latitude'], 'lng' => $row['longitude'], 'name' => $row['location']);
  }

  echo json_encode(array('locations' => $locations, 'center' => calculateCenter($locations)));

  $conn->close();

  function calculateCenter($locations) {
    $numLocations = count($locations);
    $totalLat = 0;
    $totalLng = 0;

    foreach ($locations as $location) {
      $totalLat += $location['lat'];
      $totalLng += $location['lng'];
    }

    $centerLat = $totalLat / $numLocations;
    $centerLng = $totalLng / $numLocations;

    return array('lat' => $centerLat, 'lng' => $centerLng);
  }
?>
