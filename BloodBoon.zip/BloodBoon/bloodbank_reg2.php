<?php
session_start();
$bloodBankName = "";
$location = "";
$City = "";
$State = "";
$Email = "";
$Password = "";
$available_pos_A= "";
$available_pos_B = "";
$available_neg_A = "";
$available_neg_B = "";
$available_pos_AB = "";
$available_neg_AB = "";
$available_pos_O = "";
$available_neg_O = "";


$errors = array();

// Create connection
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if (isset($_POST['sub'])) {
    // receive all input values from the form
    $bloodBankName = mysqli_real_escape_string($db, $_POST['bloodBankName']);
    $location = mysqli_real_escape_string($db, $_POST['location']);
    $City = mysqli_real_escape_string($db, $_POST['City']);
    $State = mysqli_real_escape_string($db, $_POST['State']);
    $Email = mysqli_real_escape_string($db, $_POST['Email']);
    $Password = mysqli_real_escape_string($db, $_POST['Password']);
    $available_pos_A = mysqli_real_escape_string($db, $_POST['available_pos_A']);
    $available_pos_B = mysqli_real_escape_string($db, $_POST['available_pos_B']);
    $available_neg_A = mysqli_real_escape_string($db, $_POST['available_neg_A']);
    $available_neg_B = mysqli_real_escape_string($db, $_POST['available_neg_B']);
    $available_pos_AB = mysqli_real_escape_string($db, $_POST['available_pos_AB']);
    $available_neg_AB = mysqli_real_escape_string($db, $_POST['available_neg_AB']);
    $available_pos_O = mysqli_real_escape_string($db, $_POST['available_pos_O']);
    $available_neg_O = mysqli_real_escape_string($db, $_POST['available_neg_O']);

    


    // form validation
    if (empty($bloodBankName)) {
        array_push($errors, "Blood Bank name is required");
    }
    if (empty($location)) {
        array_push($errors, "Location is required");
    }
    if (empty($City)) {
        array_push($errors, "City is required");
    }

    if (empty($State)) {
        array_push($errors, "State is required");
    }
    
    if (empty($Email)) {
        array_push($errors, "Email is required");
    }

    if (empty($available_pos_A)) {
        array_push($errors, " Availability of blood group A+ is required");
    }

    if (empty($available_pos_B)) {
        array_push($errors, "Availability of blood group B+ is required");
    }
    if (empty($available_neg_A)) {
        array_push($errors, "Availability of blood group A- is required");
    }

    if (empty($available_neg_B)) {
        array_push($errors, "Availability of blood group B- is required");
    }
    if (empty($available_pos_AB)) {
        array_push($errors, "Availability of blood goup AB+ is required");
    }

    if (empty($available_neg_AB)) {
        array_push($errors, "Availability of blood group AB- is required");
    }

    if (empty($available_pos_O)) {
        array_push($errors, "Availability of blood group O+ is required");
    }
    if (empty($available_neg_O)) {
        array_push($errors, "Availability of blood group O- is required");
    }


    
    // Check if user already exists
    $user_check_query = "SELECT * FROM blood_bank_reg WHERE bloodBankName='$bloodBankName' OR Email='$Email' LIMIT 1";
    $result = $db->query($user_check_query);

    if (!$result) {
        die("Query failed: " . $db->error);
    }

    $user = $result->fetch_assoc();

    if ($user) {
        if ($user['bloodBankName'] === $bloodBankName) {
            array_push($errors, "Donor name already exists");
        }

        if ($user['Email'] === $Email) {
            array_push($errors, "Email already exists");
        }
    }
// ...
// Register user if there are no errors
if (count($errors) == 0) {
    $hashed_password = password_hash($Password, PASSWORD_DEFAULT); // Fix variable name

    $query = "INSERT INTO blood_bank_reg(bloodBankName, location, City, State, Email, Password, available_pos_A, available_pos_B, available_neg_A, available_neg_B, available_pos_AB, available_neg_AB, available_pos_O, available_neg_O) 
              VALUES ('$bloodBankName', '$location', '$City', '$State', '$Email', '$Password', '$available_pos_A', '$available_pos_B', '$available_neg_A', '$available_neg_B', '$available_pos_AB', '$available_neg_AB', '$available_pos_O', '$available_neg_O')"; // Fix duplicate column name

    $result = $db->query($query);

    if ($result) {
        $_SESSION['bloodBankName'] = $bloodBankName;
        $_SESSION['success'] = "You are now logged in";
        header('location: index.php');
        exit();
    } else {
        die("Registration failed: " . $db->error);
    }
}
// ...

}




$db->close();
?>
