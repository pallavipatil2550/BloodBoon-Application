<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php
        echo " hello world<br>\n  ";
        echo " date is :".date(j.m.y ,h:i:s)
    ?>
</body>
</html>





<?php

session_start();
if(isset($_SESSION['email']))
{
    header("location: index.php");
    exit;
}

// Include the database connection file
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}


// Initialize variables
$email = $password = "";
$err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if(empty(trim($_POST['email'])) || empty(trim($_POST['password'])))
    {
        $err = "please enter email + password";
    }
    else{
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
    }

    if(empty($err))
    {
        $sql = "SELECT email,password FROM donor_reg WHERE email= ?";
        $stmt = mysqli_prepare($db,$sql);
        mysqli_stmt_bind_param($stmt,"s",$param_username);
        $param_username = $email;

        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            if(mysqli_stmt_num_rows($stmt) == 1)
            {
                mysqli_stmt_bind_result($stmt,$email,$hashed_password);
                if(mysqli_stmt_fetch($stmt))
                {
                    if(password_verify($password,$hashed_password))
                    {
                        session_start();
                        $_SESSION["email"] = $email;
                        $_SESSION["loggedin"] = true;

                        header("location:index.php");
                    }
                }
            }
        }
    }


    
}


?>