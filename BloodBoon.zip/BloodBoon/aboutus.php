<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Blood Donation Project</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            transition: background-color 0.5s ease;
        }

        header {
            background-color: #eb4747;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            transition: box-shadow 0.3s ease;
        }

        h2 {
            color: #eb4747;
            text-align: center;
        }

        p {
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .team-member {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            margin-bottom: 15px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .team-member:hover {
            transform: scale(1.1);
        }

        .team-member img {
            width: 100px; /* Set a fixed width */
            height: 100px; 
            border-radius: 50%;
            margin-right: 15px;
            transition: transform 0.3s ease;
        }

        .team-member:hover img {
            transform: scale(1.2);
        }

        .team-member-info {
            flex: 1;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>About Us</h1>
    </header>

    <section>
        <h2>Our Mission</h2>
        <p>We are dedicated to saving lives by connecting donors with patients in need of blood transfusions. Our mission is to ensure a stable and reliable blood supply for medical treatments and emergencies.</p>

        <h2>Who We Are</h2>
        <p>We are a passionate team of individuals committed to making a positive impact on the community. Through our blood donation project, we aim to create awareness about the importance of donating blood and its life-saving potential.</p>

        <h2>Meet Our Team</h2>
        <div class="team-member" onclick="enlargeMember(this)">
             <img src="Ankita2.jpeg" alt="Team Member 1" width="100"> 
            <div class="team-member-info">
                <h3>Ankita Shankar Chavan</h3>
            </div>
        </div>

        <div class="team-member" onclick="enlargeMember(this)">
            <img src="vinayak.jpeg" alt="Team Member 2" width="100">
            <div class="team-member-info">
                <h3>Vinayak Dilip Mithare</h3>
            </div>
        </div>

        <div class="team-member" onclick="enlargeMember(this)">
            <img src="pallavi.jpeg" alt="Team Member 3" width="100">
            <div class="team-member-info">
                <h3>Pallavi Suresh Patil</h3>
            </div>
        </div>
    </section>

    <footer>
        &copy; 2023 Blood Boon Project
    </footer>

    <script>
        function enlargeMember(element) {
            element.classList.toggle("enlarged");
        }
    </script>
</body>
</html>
