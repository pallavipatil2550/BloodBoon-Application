

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bloodboon";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Get the selected blood group and city from the form
   // $selectedBlood = $_POST['selectedBlood'];
    $city = $_POST['city'];

    // SQL query to search for blood banks based on the selected blood group and city
    $sql = "SELECT * FROM blood_bank_reg WHERE  city = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s",$city);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if there are matching records
    if ($result->num_rows > 0) {
        // Display the attributes of the matching blood banks
        while ($row = $result->fetch_assoc()) {
            echo "Blood Bank ID: " . $row['BBID'] . "<br>";
            echo "Name: " . $row['bloodBankName'] . "<br>";
            echo "Location: " . $row['location'] . "<br>";
            // Add other attributes as needed
            echo "<hr>";
        }
    } else {
        // Display a message if no matching records are found
        echo "No blood banks available in the specified location for the selected blood group.";
    }

    // Close the database connection
    $stmt->close();
}