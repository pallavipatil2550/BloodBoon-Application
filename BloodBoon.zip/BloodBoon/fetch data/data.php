<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Banks</title>
<style>


        body {
            font-family: 'PT Sans', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; 
            flex-direction: column;
            
        }

        .container {
            width: 80%;
            max-width: 800px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
            transition: box-shadow 0.3s ease-in-out;
            overflow-y: auto;
            
        }

        .container:hover {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on hover */
        }

        h2 {
            font-size: 2rem;
            font-weight: 600;
            color: lightcoral;
            text-align: center;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        .blood-bank-info {
            background-color: rgb(245, 236, 245);
            padding: 20px;
            border-radius: 1rem;
            box-shadow: 0 0 5px rgb(236, 68, 90, 0.1);
            margin-bottom: 20px;
            transition: box-shadow 0.3s ease-in-out;
        }

        .blood-bank-info:hover {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on hover */
        }

        .blood-bank-info h3 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: #007bff;
        }

        .blood-bank-info p {
            margin: 0;
            font-size: 1.2rem;
        }

        .blood-bank-info hr {
            margin-top: 15px;
            margin-bottom: 15px;
            border: 0.5px solid #ddd;
        }

        button {
            background-color: var(--clr6);
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
            font-size: 1rem;
        }

        button:hover {
            background-color: var(--clr2);
            color: #fff;
        }

        .google-map-container {
            width: 80%;
            max-width: 800px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
            transition: box-shadow 0.3s ease-in-out;
            overflow-y: auto;
        }

        .google-map-container:hover {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on hover */
        }

        .additional-container {
            width: 80%;
            max-width: 800px;
            background-color: #f4f4f4;
            padding: 20px;
            margin-top: 20px;
            overflow-y: auto;
        }
        a{
            text-align: center;
            
        }

        .location {
            background-color: rgb(245, 236, 245);
            padding: 20px;
            border-radius: 1rem;
            box-shadow: 0 0 5px rgb(236, 68, 90, 0.1);
            margin-bottom: 20px;
            transition: box-shadow 0.3s ease-in-out;
        }

        .location:hover {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on hover */
        }

        
    </style>
</style>




</head>
<body>

<?php
// display_blood_banks.php

        // Retrieve the selected city and taluka from the form
        $selectedCity = isset($_POST['city']) ? $_POST['city'] : '';
        $selectedTaluka = isset($_POST['taluka']) ? $_POST['taluka'] : '';

        // Connect to your MySQL database (replace these details with your own)
        $host = 'localhost';
        $username = 'root';
        $password = '';
        $database = 'bloodboon';

        $conn = new mysqli($host, $username, $password, $database);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query blood banks based on the selected taluka
        $sqlTaluka = "SELECT * FROM blood_bank_reg WHERE taluka = ?";
        $stmtTaluka = $conn->prepare($sqlTaluka);
        $stmtTaluka->bind_param("s", $selectedTaluka);
        $stmtTaluka->execute();

        // Get the result for taluka
        $resultTaluka = $stmtTaluka->get_result();

        // Query blood banks based on the selected city
        $sqlCity = "SELECT * FROM blood_bank_reg WHERE city = ?";
        $stmtCity = $conn->prepare($sqlCity);
        $stmtCity->bind_param("s", $selectedCity);
        $stmtCity->execute();

        // Get the result for city
        $resultCity = $stmtCity->get_result();

        // Display the blood banks
        echo '<div class="container">';
        echo "<h2>Blood Banks</h2>";
        echo "<ul>";

        // Check if there are matching blood banks for the selected taluka
        if ($resultTaluka->num_rows > 0) {
            //echo "<h3>Taluka Matching Blood Banks</h3>";
            // Display the attributes of the matching blood banks for taluka
            while ($row = $resultTaluka->fetch_assoc()) {
                echo '<li class="blood-bank-info">';
                echo "<p> Blood Bank ID  :  " . $row['BBID'] . "</p>";
                echo "<p>Name  :  " . $row['bloodBankName'] . "</p>";
                echo "<p>Location  :  " . $row['location'] . " ";
                echo "<button onclick='copyLocation(\"" . $row['bloodBankName'] . "\", \"" . $row['location'] . "\")'>📋</button></p>";
                echo "<hr>";
                echo '</li>';

            }
        } elseif ($resultCity->num_rows > 0) {
            // Check if there are matching blood banks for the selected city
            //echo "<h3>City Matching Blood Banks</h3>";
            // Display the attributes of the matching blood banks for city
            while ($row = $resultCity->fetch_assoc()) {
                echo '<li class="blood-bank-info">';
                echo "<p>Blood Bank ID :  " . $row['BBID'] . "</p>";
                echo "<p>Name  :  " . $row['bloodBankName'] . "</p>";
                echo "<p>Location  :  " . $row['location'] . " ";
                echo "<button onclick='copyLocation(\"" . $row['bloodBankName'] . "\", \"" . $row['location'] . "\")'>📋</button></p>";
                echo "<hr>";
                echo '</li>';

            }
        } else {
            // Display a message if no blood banks are available for the selected city or taluka
            echo "<li>No any nearest blood banks available in the selected city or taluka.</li>";
        }

        echo "</ul>";
        echo '</div>';

        // Close the database connection
        $stmtTaluka->close();
        $stmtCity->close();
        $conn->close();
?>
<br>
<br>
<div class="google-map-container">
    <h2>Google Map</h2>
    <div class="location">
    <p>copy the above location by clicking on clipboard</p>
    <a href="https://maps.google.com" target="_blank"> location</a>
    </div>
</div>

<div class="additional-container">
    
    <!-- Your content for the additional container goes here -->
</div>

</body>
<script>
    
    function copyLocation(bloodBankName, location) {
        // Combine the blood bank name and location
        var combinedText = "Blood Bank: " + bloodBankName + "\nLocation: " + location;

        // Create a temporary textarea element to copy the text to the clipboard
        var tempTextArea = document.createElement('textarea');
        tempTextArea.value = combinedText;
        document.body.appendChild(tempTextArea);

        // Select the text in the textarea
        tempTextArea.select();
        tempTextArea.setSelectionRange(0, 99999); /* For mobile devices */

        // Copy the text to the clipboard
        document.execCommand('copy');

        // Remove the temporary textarea
        document.body.removeChild(tempTextArea);

        // Optionally, provide feedback to the user
        alert('Blood bank information copied to clipboard:\n\n' + combinedText);
    }

    
</script>


</html>
