<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Banks</title>
<style>


        body {
            font-family: 'PT Sans', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; 
            flex-direction: column;
            
        }

        .container {
            width: 80%;
            max-width: 800px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
            transition: box-shadow 0.3s ease-in-out;
            overflow-y: auto;
            
        }

        .container:hover {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on hover */
        }

        h2 {
            font-size: 2rem;
            font-weight: 600;
            color: lightcoral;
            text-align: center;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        .blood-bank-info {
            background-color: rgb(245, 236, 245);
            padding: 20px;
            border-radius: 1rem;
            box-shadow: 0 0 5px rgb(236, 68, 90, 0.1);
            margin-bottom: 20px;
            transition: box-shadow 0.3s ease-in-out;
        }
        .blood-bank-info:hover {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box-shadow on hover */
        }

        .blood-bank-info h3 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: #007bff;
        }

        .blood-bank-info p {
            margin: 0;
            font-size: 1.2rem;
        }

        .blood-bank-info hr {
            margin-top: 15px;
            margin-bottom: 15px;
            border: 0.5px solid #ddd;
        }

        

        
        .additional-container {
            width: 80%;
            max-width: 800px;
            background-color: #f4f4f4;
            padding: 20px;
            margin-top: 20px;
            overflow-y: auto;
        }


        
    </style>
</style>




</head>
<body>

<?php

$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "SELECT * FROM blood_bank_reg";
$result = mysqli_query($db,$sql);


echo '<div class="container">';
echo "<h2> Registerd Blood Banks</h2>";
echo "<ul>";

$num = mysqli_num_rows($result);

if($num>0){

while($row = mysqli_fetch_assoc($result)){

                echo '<li class="blood-bank-info">';
                echo "<p> Blood Bank ID  :  " . $row['BBID'] . "</p>";
                echo "<p>Name  :  " . $row['bloodBankName'] . "</p>";
                echo "<p>Location  :  " . $row['location'] . " ";
                echo "<hr>";
                echo '</li>';
}
}
echo "</ul>";
echo '</div>';


?>

<div class="additional-container">
    
    <!-- Your content for the additional container goes here -->
</div>
</body>