<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "bloodboon";

// Create connection
$db = new mysqli('localhost', 'root', '', 'bloodboon');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>


