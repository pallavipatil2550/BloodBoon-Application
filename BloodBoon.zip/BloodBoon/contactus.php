<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Blood Donation Project</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #fff; /* White background color */
            color: #333; /* Dark text color */
        }

        header {
            background-color: #eb4747; 
            color: #fff; /* White text color */
            padding: 20px;
            text-align: center;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 30px;
        }

        .info-section {
            padding: 60px;
            background-color:  #eb4747; /* Light red background color */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Light shadow */
            width: 30%; /* Adjusted width */
        }

        .info-section h3 {
            color: #fffefe; /* Dark red heading color */
            margin-bottom: 15px;
            font-size: 24px; /* Increased font size */
        }

        .contact-details {
            display: flex;
            flex-direction: column;
            align-items: left;
        }

        .contact-details p {
            margin: 10px 0; /* Increased margin */
            font-size: 18px; /* Increased font size */
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            color:rgb(255, 255, 127)
        }

        footer {
            background-color: #000000; /* Grey footer background color */
            color: #ffffff; /* Dark text color */
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
        }
    </style>
</head>
<body>

    <header>
        <h1>Contact Us</h1>
    </header>

    <div class="container">
        <div class="info-section">
            <h3>Contact Details</h3>
            <div class="contact-details">
                <p>Email: info@blooddonationproject.com</p>
                <p>Phone: 8919906447 </p>
                <p>LinkedIn: linkedin.com/blooddonationproject</p>
                <p>Instagram: @blooddonationproject</p>
                <!-- Add more details as needed -->
            </div>
        </div>
    </div>

    <footer>
        &copy; 2023 Blood Boon Project
    </footer>

</body>
</html>
